---
title: "Research"
date: 2018-08-02T16:14:13-07:00
draft: false
---

<h4>questions</h4>
<ul>
  <li>uncertainty</li>
  <li>divergent thinking</li>
  <li>feedback</li>
  <li>horizontal pedagogy</li>
</ul>

<h4>methods</h4>
<ul>
  <li>microgenetic</li>
  <li>psychometrics</li>
  <li>sociocultural</li>
  <li>in situ</li>
</ul>

<h4>collaborations</h4>
<ul>
  <li>data visualizations</li>
  <li>educational</li>
  <li>creative process</li>
  <li>modeling</li>
</ul>
