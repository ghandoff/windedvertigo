---
title: "courses"
date: 2018-08-02T16:15:49-07:00
draft: false
---

<h4><b>syllabi + resources</b></h4>

<table>
<thead>
<tr class="header">
<th><strong>course title</strong></th>
<th>class size</th>
<th>[semester]</th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td>
<p><em><strong>qualitative research in child development</strong> [lecture + lab]</em></p>
</td>
<td>14</td>
<td>[summer2017]</td>
</tr>
<tr class="even">
<td>
<p>undergraduate [california state university, sacramento]</p>
</td>
<td>130</td>
<td>[spring 2017]</td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>
<p><em><strong>cognitive development</strong> [lecture + lab]</em></p>
</td>
<td>45</td>
<td>[spring 2017]</td>
</tr>
<tr class="odd">
<td>
<p>undergraduate [california state university, sacramento]</p>
</td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td>
<p><em><strong>observation &amp; assessment in child development</strong> [lecture + lab]</em></p>
</td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>
<p>undergraduate [california state university, sacramento]</p>
</td>
<td>85</td>
<td>[fall 2016]</td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>
<p><em><strong>social, personality, &amp; emotional development</strong> [hybrid/online]</em></p>
</td>
<td>41</td>
<td>[fall 2016]</td>
</tr>
<tr class="odd">
<td>
<p>undergraduate [san francisco state university]</p>
</td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td>
<p><em><strong>developmental psychology</strong> [lecture]</em></p>
</td>
<td>48</td>
<td>[fall 2016]</td>
</tr>
<tr class="even">
<td>
<p>undergraduate [san francisco state university]</p>
</td>
<td>39</td>
<td>[fall 2015]</td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td>
<p><em><strong>cognitive Development</strong> [seminar]</em></p>
</td>
<td>13</td>
<td>[summer2016]</td>
</tr>
<tr class="odd">
<td>
<p>undergraduate [san francisco state university]</p>
</td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="odd">
<td>
<p><em><strong>child development</strong> [lecture]</em></p>
</td>
<td>63</td>
<td>[spring 2016]</td>
</tr>
<tr class="even">
<td>
<p>undergraduate [san francisco state university]</p>
</td>
<td>38</td>
<td>[fall 2015]</td>
</tr>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
</table>
