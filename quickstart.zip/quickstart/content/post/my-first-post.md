---
title: "my first post"
date: 2018-07-30
tags: []
draft: false
image: "/resources/glass_floor.jpg"
---
vertigo via visuals

<iframe src="https://giphy.com/embed/PZEUtFEJxgjy8" width="480" height="480" frameBorder="0" class="giphy-embed" allowFullScreen></iframe><p><a href="https://giphy.com/gifs/xpost-satisfying-vertigo-PZEUtFEJxgjy8">morphing</a></p>

<iframe src="https://giphy.com/embed/5a4C4ZdxTUqKA" width="472" height="480" frameBorder="0" class="giphy-embed" allowFullScreen></iframe><p><a href="https://giphy.com/gifs/corner-vertigo-gonwild-5a4C4ZdxTUqKA">tracking</a></p>
