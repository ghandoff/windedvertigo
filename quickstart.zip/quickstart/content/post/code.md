---
title: "code"
date: 2018-07-30
tags: []
draft: false
---
```r
  num1 == 16
  num2 == 32
  print(num1 + num2)
```
