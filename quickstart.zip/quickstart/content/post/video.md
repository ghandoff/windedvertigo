---
title: "video"
date: 2018-07-30
tags: []
draft: false
---
christoph niemann

<iframe width="560" height="315" src="https://embed.ted.com/talks/christoph_niemann_you_are_fluent_in_this_language_and_don_t_even_know_it" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

hugo shortcodes
{{<youtube Eu4zSaKOY4A>}}
