---
title: "tools"
date: 2018-08-02T16:15:59-07:00
draft: false
---
<hr>
<h3><center>data</center></h3>
<h4>quant</h4>
<h5><em>excel</em></h5>
<ul>
  <li>confusion matrix</li>
  <li>auto-intervals</li>
  <li>tall-to-wide</li>
  <li>auto-intervals</li>
</ul>
<h5><em>r</em></h5>
<ul>
  <li>confusion matrix</li>
  <li>auto-intervals</li>
  <li>tall-to-wide</li>
  <li>auto-intervals</li>
</ul>

<h4>qual</h4>
<h5>datavyu</h5>
<ul>
  <li>setup</li>
  <li>transcription</li>
  <li>coding</li>
  <li>ruby scripts</li>
</ul>

<hr>
<h3><center>podcast</center></h3>
<ul>
  <li>sep1</li>
  <li>sep2</li>
</ul>
